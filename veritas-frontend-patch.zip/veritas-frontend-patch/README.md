# Veritas frontend patch

This patch splits the App Router into `/home`, `/a1`, `/a2`, and `/a3`. View-specific styling lives in CSS Modules; `globals.css` contains only the small reset and page defaults.

## 1. Install React Three Fiber

Check the installed React major version in `frontend/package.json` or run `npm ls react`.

- React 19: `npm install three @types/three @react-three/fiber@^9`
- React 18: `npm install three @types/three @react-three/fiber@^8`

## 2. Copy the patch

Copy the contents of this patch's `src/app/` directory into your project's `frontend/src/app/`, merging the folders. Keep your backend and Docker services unchanged.

The patch expects:

- FastAPI: `http://localhost:8000`, `POST /api/verify`
- Existing graph viewer: `http://localhost:8080`

Set these in `frontend/.env.local` if different:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_GRAPH_URL=http://localhost:8080
```

## 3. Run

```bash
cd ~/Desktop/kafka/kafka/frontend
npm run dev
```

Open `http://localhost:3000` (redirects to `/home`).

## Notes

- Submit stores the claim in `sessionStorage`, starts the rightward light sweep, then navigates to `/a1`.
- `/a1` then calls the real FastAPI endpoint and embeds the existing graph viewer.
- `/a2` and `/a3` are route shells only; they do not pretend that those backend stages have been wired yet.
- The 3D background is decorative context on Home only. A1's graph remains your actual existing visualization.
