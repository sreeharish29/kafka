"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import styles from "./a1.module.css";

type A1Payload = {
  status?: string;
  session_id?: string;
  sentence?: string;
  stage?: string;
  a1?: {
    status?: string;
    already_present_in_db?: string;
    memory?: unknown;
    entities_found?: number;
  };
  execution_time_seconds?: number;
  timestamp?: string;
};

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const GRAPH_URL = process.env.NEXT_PUBLIC_GRAPH_URL || "http://localhost:8080";

export default function A1Page() {
  const started = useRef(false);
  const [claim, setClaim] = useState("");
  const [data, setData] = useState<A1Payload | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const currentClaim = window.sessionStorage.getItem("veritas:claim") || "";
    setClaim(currentClaim);
    if (!currentClaim) {
      setLoading(false);
      setError("No claim was received. Return to Home and submit a sentence.");
      return;
    }

    fetch(`${API_URL}/api/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sentence: currentClaim }),
    })
      .then(async (response) => {
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.detail || body.message || `API returned ${response.status}`);
        return body as A1Payload;
      })
      .then(setData)
      .catch((reason: unknown) => {
        if (reason instanceof Error && reason.name !== "AbortError") setError(reason.message);
      })
      .finally(() => setLoading(false));

  }, []);

  const memoryText = data?.a1?.memory === undefined
    ? "No memory payload was returned."
    : JSON.stringify(data.a1.memory, null, 2);

  return (
    <main className={styles.workspace}>
      <header className={styles.header}>
        <Link href="/home" className={styles.brand}><span>V</span><b>VERITAS</b><small>CLAIM INTELLIGENCE</small></Link>
        <nav className={styles.stageNav} aria-label="Stages">
          <Link className={styles.active} href="/a1">A1 <small>MEMORY</small></Link>
          <Link href="/a2">A2 <small>INTENT</small></Link>
          <Link href="/a3">A3 <small>RESEARCH</small></Link>
        </nav>
        <div className={styles.live}><i /> LIVE SESSION</div>
      </header>

      <section className={styles.claimBar}>
        <div><span className={styles.kicker}>CLAIM UNDER INVESTIGATION</span><p>{claim || "No claim submitted"}</p></div>
        <Link href="/home" className={styles.newClaim}>+ NEW CLAIM</Link>
      </section>

      <div className={styles.layout}>
        <aside className={styles.leftPanel}>
          <div className={styles.panelTitle}><span>01</span> A1 / MEMORY RETRIEVAL</div>
          <div className={styles.runState}><div className={loading ? styles.spinner : styles.check}>{loading ? "" : data ? "✓" : "!"}</div><div><b>{loading ? "Retrieval in progress" : data ? "A1 execution complete" : "A1 execution stopped"}</b><small>{loading ? "Awaiting backend response" : data ? "Response received from FastAPI" : "Check API connectivity"}</small></div></div>
          <div className={styles.metric}><small>STAGE</small><b>A1</b><span>Memory check</span></div>
          <div className={styles.metric}><small>ENTITIES FOUND</small><b>{data?.a1?.entities_found ?? (loading ? "—" : "0")}</b><span>Reported by A1</span></div>
          <div className={styles.metric}><small>DATABASE MATCH</small><b className={data?.a1?.already_present_in_db === "yes" ? styles.match : ""}>{loading ? "—" : data?.a1?.already_present_in_db?.toUpperCase() || "N/A"}</b><span>Structured DBCheck result</span></div>
          {error && <div className={styles.errorBox}>{error}</div>}
        </aside>

        <section className={styles.graphPanel}>
          <div className={styles.panelTitle}><span>02</span> KNOWLEDGE GRAPH <small>LIVE VIEW</small><a href={GRAPH_URL} target="_blank" rel="noreferrer">OPEN ↗</a></div>
          <iframe title="Existing Veritas knowledge graph" src={GRAPH_URL} className={styles.graphFrame} />
        </section>

        <aside className={styles.rightPanel}>
          <div className={styles.panelTitle}><span>03</span> A1 RESPONSE</div>
          <div className={styles.responseHead}><b>{loading ? "PROCESSING" : data ? "COMPLETED" : "FAILED"}</b><span>{data?.execution_time_seconds !== undefined ? `${data.execution_time_seconds.toFixed(2)}s` : "—"}</span></div>
          <p className={styles.responseHint}>Raw memory payload returned by the existing A1 node.</p>
          <pre className={styles.memoryOutput}>{loading ? "Waiting for A1…" : memoryText}</pre>
          {data?.session_id && <div className={styles.sessionId}><small>SESSION ID</small><code>{data.session_id}</code></div>}
          {data && <button className={styles.copyButton} onClick={() => navigator.clipboard?.writeText(JSON.stringify(data, null, 2))}>COPY RESPONSE</button>}
        </aside>
      </div>
      <footer className={styles.footer}><span>VERITAS / A1 MEMORY STAGE</span><span>{data?.timestamp ? new Date(data.timestamp).toLocaleString() : "SESSION ACTIVE"}</span></footer>
    </main>
  );
}
