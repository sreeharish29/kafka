"use client";

import dynamic from "next/dynamic";
import { type AnimationEvent, type FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./home.module.css";

const LightField = dynamic(() => import("../components/LightField"), {
  ssr: false,
  loading: () => <div className={styles.canvasFallback} aria-hidden="true" />,
});

export default function HomePage() {
  const router = useRouter();
  const [claim, setClaim] = useState("");
  const [transitioning, setTransitioning] = useState(false);
  const [error, setError] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = claim.trim();
    if (!value) {
      setError("Enter a sentence or claim to begin.");
      return;
    }
    if (transitioning) return;
    setError("");
    window.sessionStorage.setItem("veritas:claim", value);
    setTransitioning(true);
  }

  function finishTransition(event: AnimationEvent<HTMLDivElement>) {
    if (event.animationName === "curtainHold") router.push("/a1");
  }

  return (
    <main className={styles.home}>
      <div className={styles.scene} aria-hidden="true"><LightField /></div>
      <div className={styles.vignette} aria-hidden="true" />
      <header className={styles.topbar}>
        <a className={styles.brand} href="/home" aria-label="Veritas home">
          <span className={styles.brandMark}>V</span>
          <span className={styles.brandWords}><strong>VERITAS</strong><small>INTELLIGENCE SYSTEM</small></span>
        </a>
        <div className={styles.systemStatus}><span /> SYSTEM ONLINE</div>
      </header>

      <section className={styles.hero}>
        <div className={styles.eyebrow}><span /> AI-POWERED CLAIM INTELLIGENCE <i>01 / 04</i></div>
        <h1>Verify the given<br /><em>sentence.</em></h1>
        <p className={styles.intro}>Trace a claim through connected memory, knowledge graphs<br className={styles.desktopBreak} /> and evidence retrieval.</p>

        <form className={styles.inputPanel} onSubmit={submit}>
          <label htmlFor="claim-input">CLAIM TO INVESTIGATE</label>
          <textarea
            id="claim-input"
            value={claim}
            onChange={(event) => { setClaim(event.target.value); setError(""); }}
            placeholder="Enter a sentence or claim to verify..."
            maxLength={1800}
            rows={3}
            disabled={transitioning}
            onKeyDown={(event) => {
              if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
                event.preventDefault();
                event.currentTarget.form?.requestSubmit();
              }
            }}
          />
          <div className={styles.formFooter}>
            <span className={styles.hint}>CTRL <kbd>↵</kbd> TO SUBMIT</span>
            <button className={`${styles.verifyButton} ${transitioning ? styles.isTracing : ""}`} type="submit" disabled={transitioning || !claim.trim()}>
              <span className={styles.buttonSpark}>✦</span>
              {transitioning ? "Tracing claim" : "Verify sentence"}
              <span className={styles.buttonArrow}>→</span>
            </button>
          </div>
          {error && <p className={styles.error}>{error}</p>}
        </form>

        <div className={styles.capabilities}>
          <span>MEMORY ENGINE</span><b />
          <span>KNOWLEDGE GRAPH</span><b />
          <span>LIVE ANALYSIS</span>
        </div>
      </section>

      <footer className={styles.footer}>
        <span>VERITAS <i>•</i> CLAIM INTELLIGENCE</span>
        <span>CONNECTED REASONING / REAL-TIME RETRIEVAL</span>
      </footer>

      {transitioning && (
        <div className={styles.transitionCurtain} onAnimationEnd={finishTransition} aria-hidden="true">
          <div className={styles.transitionCore} />
        </div>
      )}
    </main>
  );
}
