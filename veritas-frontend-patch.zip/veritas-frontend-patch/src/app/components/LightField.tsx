"use client";

import { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

const COLORS = ["#8f72ff", "#d47bff", "#ff639d", "#a7caff", "#f5a7ce"];

function LightStrand({ index }: { index: number }) {
  const mesh = useRef<THREE.Mesh>(null);
  const curve = useMemo(() => {
    const points = Array.from({ length: 48 }, (_, i) => {
      const t = i / 47;
      const x = -8.2 + t * 16.4;
      const wave = Math.sin(t * Math.PI * 2.15 + index * 0.72) * (0.32 + (index % 3) * 0.09);
      const y = (index - 2) * 0.34 + wave;
      const z = -0.7 + Math.cos(t * Math.PI * 2 + index * 0.45) * 0.25;
      return new THREE.Vector3(x, y, z);
    });
    return new THREE.CatmullRomCurve3(points);
  }, [index]);

  useFrame(({ clock }) => {
    if (mesh.current) mesh.current.position.y = Math.sin(clock.elapsedTime * 0.34 + index) * 0.035;
  });

  return (
    <mesh ref={mesh}>
      <tubeGeometry args={[curve, 150, index === 2 ? 0.012 : 0.006, 6, false]} />
      <meshBasicMaterial
        color={COLORS[index % COLORS.length]}
        transparent
        opacity={index === 2 ? 0.34 : 0.19}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </mesh>
  );
}

function PulseNode({ position, color, size, phase }: {
  position: [number, number, number]; color: string; size: number; phase: number;
}) {
  const node = useRef<THREE.Mesh>(null);
  const halo = useRef<THREE.Mesh>(null);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime + phase;
    if (node.current) {
      const scale = 0.82 + (Math.sin(t * 1.45) + 1) * 0.16;
      node.current.scale.setScalar(scale);
      node.current.position.y = position[1] + Math.sin(t * 0.5) * 0.035;
    }
    if (halo.current) {
      const scale = 1.6 + (Math.sin(t * 1.45) + 1) * 0.6;
      halo.current.scale.setScalar(scale);
      const material = halo.current.material as THREE.MeshBasicMaterial;
      material.opacity = 0.07 + (Math.sin(t * 1.45) + 1) * 0.035;
    }
  });

  return (
    <group position={position}>
      <mesh ref={halo}>
        <sphereGeometry args={[size, 12, 12]} />
        <meshBasicMaterial color={color} transparent opacity={0.1} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>
      <mesh ref={node}>
        <sphereGeometry args={[size * 0.55, 16, 16]} />
        <meshBasicMaterial color={color} toneMapped={false} />
      </mesh>
    </group>
  );
}

function Dust() {
  const points = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const data = new Float32Array(420 * 3);
    for (let i = 0; i < 420; i += 1) {
      const a = Math.sin(i * 127.1) * 43758.5453;
      const b = Math.sin(i * 311.7) * 24634.6345;
      const c = Math.sin(i * 74.7) * 9631.417;
      data[i * 3] = ((a - Math.floor(a)) - 0.5) * 17;
      data[i * 3 + 1] = ((b - Math.floor(b)) - 0.5) * 8.8;
      data[i * 3 + 2] = ((c - Math.floor(c)) - 0.5) * 3 - 1.2;
    }
    return data;
  }, []);
  useFrame(({ clock }) => {
    if (points.current) {
      points.current.rotation.y = Math.sin(clock.elapsedTime * 0.06) * 0.045;
      points.current.rotation.z = Math.sin(clock.elapsedTime * 0.035) * 0.012;
    }
  });
  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#c4b8e8" size={0.012} transparent opacity={0.42} sizeAttenuation depthWrite={false} />
    </points>
  );
}

function Scene() {
  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[3.7, 0.3, 2]} color="#ff5c9e" intensity={2.1} distance={8} />
      <pointLight position={[-3.8, -0.6, 1]} color="#8267ff" intensity={1.2} distance={8} />
      {Array.from({ length: 5 }, (_, i) => <LightStrand key={i} index={i} />)}
      <PulseNode position={[3.7, 0.55, 0.15]} color="#ff83b7" size={0.085} phase={0.2} />
      <PulseNode position={[-2.6, -0.65, 0.1]} color="#a18aff" size={0.055} phase={1.4} />
      <PulseNode position={[0.7, 0.08, -0.1]} color="#d8c5ff" size={0.045} phase={2.1} />
      <PulseNode position={[5.6, -0.62, 0]} color="#85bfff" size={0.05} phase={0.8} />
      <Dust />
    </>
  );
}

export default function LightField() {
  return (
    <Canvas
      camera={{ position: [0, 0, 7.5], fov: 48 }}
      dpr={[1, 1.35]}
      gl={{ alpha: true, antialias: false, powerPreference: "low-power" }}
      frameloop="always"
      fallback={<div aria-hidden="true" />}
    >
      <Scene />
    </Canvas>
  );
}
