import Link from "next/link";
import styles from "../stage.module.css";

export default function A2Page() {
  return <main className={styles.stagePage}>
    <header className={styles.header}><Link href="/home" className={styles.brand}><span>V</span> VERITAS</Link><nav><Link href="/a1">A1 · MEMORY</Link><b>A2 · INTENT</b><Link href="/a3">A3 · RESEARCH</Link></nav></header>
    <section className={styles.content}><small>STAGE 02 / INTENT CLASSIFICATION</small><h1>A2 <em>Intent analysis</em></h1><p>This route is ready for the A2 node integration. No classification is fabricated on this screen.</p><Link href="/a1">← BACK TO A1</Link></section>
  </main>;
}
