import Link from "next/link";
import styles from "../stage.module.css";

export default function A3Page() {
  return <main className={styles.stagePage}>
    <header className={styles.header}><Link href="/home" className={styles.brand}><span>V</span> VERITAS</Link><nav><Link href="/a1">A1 · MEMORY</Link><Link href="/a2">A2 · INTENT</Link><b>A3 · RESEARCH</b></nav></header>
    <section className={styles.content}><small>STAGE 03 / REFERENCE RESOLUTION</small><h1>A3 <em>Search &amp; evidence</em></h1><p>This route is ready for the A3 node integration. It is not yet connected to the backend pipeline.</p><Link href="/a1">← BACK TO A1</Link></section>
  </main>;
}
